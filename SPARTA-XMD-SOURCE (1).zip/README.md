
# ⚔️ SPARTA-XMD – AI WhatsApp Bot

Welcome to **SPARTA-XMD**, a powerful AI-powered WhatsApp bot built with [Baileys](https://github.com/WhiskeySockets/Baileys).  
Developed by **Sparta-28**, this bot delivers tools, AI features, media downloads, group management, and much more.

---

## 🚀 Features

- ✅ Button-based menu with media header
- 🤖 AI Assistant via OpenAI GPT
- 🎵 Media tools: Downloaders, Audio FX, Image Search
- 🔒 Admin & Anti-crash systems
- 👥 Group moderation
- 🧠 Smart auto-reply and chatbot
- 🛡️ Crash filtering, blocklist, anti-call
- 🌐 Web Panel & QR Auto-login ready
- 🔁 CI/CD with GitHub Actions → Heroku auto-deploy

---

## 🧪 Commands Preview

Use `.menu` to access:

```
OWNER 
| GROUP 
| TOOLS 
| DOWNLOADS 
| AUDIO 
| REACT 
| SETTINGS 
| SEARCH 
| AI 
| MORE
```

---

## 📦 Installation (Local)

```bash
git clone https://github.com/BMM-28/SPARTA-XMD.git
cd SPARTA-XMD
npm install
npm start
```

---

## ⚙️ Deployment – Heroku

1. Push to GitHub
2. Connect repo to Heroku
3. Add environment variables (see below)
4. Enable Auto Deploy from `main`

---

## 🔐 Environment Variables

Create a `.env` file or set Heroku Config Vars:

```
OPENAI_API_KEY=sk-xxxxxxx
OWNER_NUMBER=254795452444
NODE_ENV=production
```

---

## 🙏 Credits

- 👑 Developer: SPARTA-28
- 💡 XFACTA (Best Friend)
- ⚔️ COMBATS Clan
- 🧠 GPT (Helper)
- 🕋 ALLAH (Everything 💞)

---

## 📖 License

MIT – Powered by SPARTA-XMD | Use with credit

