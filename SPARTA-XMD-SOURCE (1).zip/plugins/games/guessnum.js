
module.exports = {
  name: 'guessnum',
  command: ['guessnum'],
  category: 'games',
  description: 'guessnum command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *guessnum* command executed.');
  }
};
