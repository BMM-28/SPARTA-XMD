
module.exports = {
  name: 'tictactoe',
  command: ['tictactoe'],
  category: 'games',
  description: 'tictactoe command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *tictactoe* command executed.');
  }
};
