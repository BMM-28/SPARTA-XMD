
module.exports = {
  name: 'rps',
  command: ['rps'],
  category: 'games',
  description: 'rps command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *rps* command executed.');
  }
};
