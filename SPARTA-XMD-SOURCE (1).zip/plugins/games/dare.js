
module.exports = {
  name: 'dare',
  command: ['dare'],
  category: 'games',
  description: 'dare command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *dare* command executed.');
  }
};
