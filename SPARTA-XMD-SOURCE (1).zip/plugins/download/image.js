
module.exports = {
  name: 'image',
  command: ['image'],
  category: 'download',
  description: 'image command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *image* command executed.');
  }
};
