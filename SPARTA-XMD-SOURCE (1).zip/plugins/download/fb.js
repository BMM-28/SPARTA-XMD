
module.exports = {
  name: 'fb',
  command: ['fb'],
  category: 'download',
  description: 'fb command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *fb* command executed.');
  }
};
