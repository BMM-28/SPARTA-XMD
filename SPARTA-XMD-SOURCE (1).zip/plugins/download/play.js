
module.exports = {
  name: 'play',
  command: ['play'],
  category: 'download',
  description: 'play command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *play* command executed.');
  }
};
