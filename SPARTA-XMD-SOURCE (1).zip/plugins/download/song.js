
module.exports = {
  name: 'song',
  command: ['song'],
  category: 'download',
  description: 'song command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *song* command executed.');
  }
};
