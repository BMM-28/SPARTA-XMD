
module.exports = {
  name: 'video',
  command: ['video'],
  category: 'download',
  description: 'video command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *video* command executed.');
  }
};
