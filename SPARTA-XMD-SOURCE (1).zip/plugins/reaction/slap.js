
module.exports = {
  name: 'slap',
  command: ['slap'],
  category: 'reaction',
  description: 'slap command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *slap* command executed.');
  }
};
