
module.exports = {
  name: 'cry',
  command: ['cry'],
  category: 'reaction',
  description: 'cry command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *cry* command executed.');
  }
};
