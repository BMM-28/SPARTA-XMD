
module.exports = {
  name: 'smile',
  command: ['smile'],
  category: 'reaction',
  description: 'smile command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *smile* command executed.');
  }
};
