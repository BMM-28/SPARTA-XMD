
module.exports = {
  name: 'wave',
  command: ['wave'],
  category: 'reaction',
  description: 'wave command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *wave* command executed.');
  }
};
