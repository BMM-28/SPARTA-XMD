
module.exports = {
  name: 'hug',
  command: ['hug'],
  category: 'reaction',
  description: 'hug command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *hug* command executed.');
  }
};
