
module.exports = {
  name: 'kiss',
  command: ['kiss'],
  category: 'reaction',
  description: 'kiss command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *kiss* command executed.');
  }
};
