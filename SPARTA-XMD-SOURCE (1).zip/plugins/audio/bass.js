
module.exports = {
  name: 'bass',
  command: ['bass'],
  category: 'audio',
  description: 'bass command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *bass* command executed.');
  }
};
