
module.exports = {
  name: 'tomp3',
  command: ['tomp3'],
  category: 'audio',
  description: 'tomp3 command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *tomp3* command executed.');
  }
};
