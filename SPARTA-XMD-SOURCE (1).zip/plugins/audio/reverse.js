
module.exports = {
  name: 'reverse',
  command: ['reverse'],
  category: 'audio',
  description: 'reverse command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *reverse* command executed.');
  }
};
