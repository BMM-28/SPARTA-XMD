
module.exports = {
  name: 'robot',
  command: ['robot'],
  category: 'audio',
  description: 'robot command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *robot* command executed.');
  }
};
