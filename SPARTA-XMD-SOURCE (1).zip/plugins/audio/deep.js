
module.exports = {
  name: 'deep',
  command: ['deep'],
  category: 'audio',
  description: 'deep command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *deep* command executed.');
  }
};
