
module.exports = {
  name: 'qr',
  command: ['qr'],
  category: 'tools',
  description: 'qr command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *qr* command executed.');
  }
};
