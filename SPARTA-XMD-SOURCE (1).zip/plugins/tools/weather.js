
module.exports = {
  name: 'weather',
  command: ['weather'],
  category: 'tools',
  description: 'weather command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *weather* command executed.');
  }
};
