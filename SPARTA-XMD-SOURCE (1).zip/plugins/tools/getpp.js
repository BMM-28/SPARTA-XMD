
module.exports = {
  name: 'getpp',
  command: ['getpp'],
  category: 'tools',
  description: 'getpp command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *getpp* command executed.');
  }
};
