
module.exports = {
  name: 'emojimix',
  command: ['emojimix'],
  category: 'tools',
  description: 'emojimix command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *emojimix* command executed.');
  }
};
