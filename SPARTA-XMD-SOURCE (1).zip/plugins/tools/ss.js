
module.exports = {
  name: 'ss',
  command: ['ss'],
  category: 'tools',
  description: 'ss command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *ss* command executed.');
  }
};
