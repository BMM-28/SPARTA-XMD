
module.exports = {
  name: 'getabout',
  command: ['getabout'],
  category: 'tools',
  description: 'getabout command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *getabout* command executed.');
  }
};
