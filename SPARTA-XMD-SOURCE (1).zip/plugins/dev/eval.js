
module.exports = {
  name: 'eval',
  command: ['eval'],
  category: 'dev',
  description: 'eval command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *eval* command executed.');
  }
};
