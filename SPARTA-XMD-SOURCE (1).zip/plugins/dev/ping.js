
module.exports = {
  name: 'ping',
  command: ['ping'],
  category: 'dev',
  description: 'ping command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *ping* command executed.');
  }
};
