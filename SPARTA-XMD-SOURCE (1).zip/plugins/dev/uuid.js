
module.exports = {
  name: 'uuid',
  command: ['uuid'],
  category: 'dev',
  description: 'uuid command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *uuid* command executed.');
  }
};
