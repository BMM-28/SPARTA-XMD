
module.exports = {
  name: 'getlogs',
  command: ['getlogs'],
  category: 'dev',
  description: 'getlogs command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *getlogs* command executed.');
  }
};
