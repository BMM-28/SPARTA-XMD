
module.exports = {
  name: 'reload',
  command: ['reload'],
  category: 'dev',
  description: 'reload command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *reload* command executed.');
  }
};
