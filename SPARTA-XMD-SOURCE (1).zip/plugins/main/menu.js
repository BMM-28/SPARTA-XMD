
const { default: makeWASocket, proto } = require('@whiskeysockets/baileys')
const fs = require('fs')
const path = require('path')

module.exports = {
  name: 'menu',
  command: ['menu', 'help', '?'],
  category: 'main',
  description: 'Show the full command menu',
  async handler(m, { conn }) {
    const mediaPath = path.resolve(__dirname, '../assets/logo.jpg')
    const mediaBuffer = fs.existsSync(mediaPath) ? fs.readFileSync(mediaPath) : null

    const sections = [{
      title: "📂 Select a Menu Category",
      rows: [
        { title: "📥 Download Menu", rowId: ".downloadmenu" },
        { title: "🎧 Audio Menu", rowId: ".audiomenu" },
        { title: "👥 Group Menu", rowId: ".groupmenu" },
        { title: "⚙️ Settings Menu", rowId: ".settingsmenu" },
        { title: "🤖 AI Menu", rowId: ".aimenu" },
        { title: "🎭 Fun Menu", rowId: ".funmenu" },
        { title: "😍 Reaction Menu", rowId: ".reactionmenu" },
        { title: "🎮 Games Menu", rowId: ".gamesmenu" },
        { title: "🧰 Tools Menu", rowId: ".toolsmenu" },
        { title: "🧹 Moderation Menu", rowId: ".moderationmenu" },
        { title: "🔍 Search Menu", rowId: ".searchmenu" },
        { title: "📖 Religious Menu", rowId: ".religiousmenu" },
        { title: "🧑‍💼 Owner Menu", rowId: ".ownermenu" },
        { title: "🛠️ Custom Menu", rowId: ".custommenu" },
        { title: "🆘 Support Menu", rowId: ".supportmenu" }
      ]
    }]

    const listMessage = {
      text: "*🛡️ SPARTA-XMD MENU*",
      footer: "🤖 Your AI WhatsApp Assistant is ready.
Select a category below:",
      title: "Welcome to SPARTA-XMD!",
      buttonText: "🧭 Open Menu",
      sections
    }

    if (mediaBuffer) {
      return conn.sendMessage(m.chat, {
        image: mediaBuffer,
        caption: "*🛡️ SPARTA-XMD MENU*
🤖 Your AI WhatsApp Assistant is ready.

Tap a button below to explore.
━━━━━━━━━━━━━━━━━━━━━━━
📝 *VOTE OF THANKS*

𝐒𝐏𝐀𝐑𝐓𝐀-28 (𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁)  
𝐗𝐅𝐀𝐂𝐓𝐀 (𝙱𝙴𝚂𝚃 𝙵𝚁𝙸𝙴𝙽𝙳)  
𝐂𝐎𝐌𝐁𝐀𝐓𝐒 (𝙲𝙻𝙰𝙽)  
𝐆𝐏𝐓 (𝙷𝙴𝙻𝙿𝙴𝚁)  
𝐀𝐋𝐋𝐀𝐇(𝕊.𝕎)(𝙴𝚅𝙴𝚁𝚈𝚃𝙷𝙸𝙽𝙶💞)
━━━━━━━━━━━━━━━━━━━━━━━",
        footer: "Developed by Sparta-28! welcome all!",
        title: "Welcome to SPARTA-XMD!",
        buttonText: "📂 Menu Options",
        sections
      }, { quoted: m })
    } else {
      return conn.sendMessage(m.chat, listMessage, { quoted: m })
    }
  }
}
