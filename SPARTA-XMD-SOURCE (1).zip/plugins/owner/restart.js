
module.exports = {
  name: 'restart',
  command: ['restart'],
  category: 'owner',
  description: 'restart command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *restart* command executed.');
  }
};
