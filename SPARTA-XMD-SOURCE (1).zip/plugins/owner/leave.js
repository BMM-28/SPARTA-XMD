
module.exports = {
  name: 'leave',
  command: ['leave'],
  category: 'owner',
  description: 'leave command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *leave* command executed.');
  }
};
