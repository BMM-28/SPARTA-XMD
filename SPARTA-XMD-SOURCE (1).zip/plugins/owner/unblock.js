
module.exports = {
  name: 'unblock',
  command: ['unblock'],
  category: 'owner',
  description: 'unblock command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *unblock* command executed.');
  }
};
