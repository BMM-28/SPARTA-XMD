
module.exports = {
  name: 'setpp',
  command: ['setpp'],
  category: 'owner',
  description: 'setpp command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setpp* command executed.');
  }
};
