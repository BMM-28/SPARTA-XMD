
module.exports = {
  name: 'block',
  command: ['block'],
  category: 'owner',
  description: 'block command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *block* command executed.');
  }
};
