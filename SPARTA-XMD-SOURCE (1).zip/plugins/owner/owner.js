
module.exports = {
  name: 'owner',
  command: ['owner'],
  category: 'owner',
  description: 'owner command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *owner* command executed.');
  }
};
