
module.exports = {
  name: 'roast',
  command: ['roast'],
  category: 'fun',
  description: 'roast command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *roast* command executed.');
  }
};
