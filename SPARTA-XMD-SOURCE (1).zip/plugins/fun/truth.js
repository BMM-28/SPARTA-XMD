
module.exports = {
  name: 'truth',
  command: ['truth'],
  category: 'fun',
  description: 'truth command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *truth* command executed.');
  }
};
