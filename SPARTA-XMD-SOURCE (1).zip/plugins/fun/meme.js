
module.exports = {
  name: 'meme',
  command: ['meme'],
  category: 'fun',
  description: 'meme command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *meme* command executed.');
  }
};
