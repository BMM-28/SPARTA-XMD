
module.exports = {
  name: 'pair',
  command: ['pair'],
  category: 'fun',
  description: 'pair command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *pair* command executed.');
  }
};
