
module.exports = {
  name: 'joke',
  command: ['joke'],
  category: 'fun',
  description: 'joke command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *joke* command executed.');
  }
};
