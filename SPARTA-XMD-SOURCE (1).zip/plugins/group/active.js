
module.exports = {
  name: 'active',
  command: ['active'],
  category: 'group',
  description: 'active command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *active* command executed.');
  }
};
