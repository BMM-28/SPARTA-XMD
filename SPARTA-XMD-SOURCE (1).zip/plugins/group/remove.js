
module.exports = {
  name: 'remove',
  command: ['remove'],
  category: 'group',
  description: 'remove command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *remove* command executed.');
  }
};
