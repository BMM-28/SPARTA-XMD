
module.exports = {
  name: 'antitag',
  command: ['antitag'],
  category: 'group',
  description: 'antitag command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *antitag* command executed.');
  }
};
