
module.exports = {
  name: 'add',
  command: ['add'],
  category: 'group',
  description: 'add command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *add* command executed.');
  }
};
