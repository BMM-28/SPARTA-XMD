
module.exports = {
  name: 'kickall',
  command: ['kickall'],
  category: 'group',
  description: 'kickall command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *kickall* command executed.');
  }
};
