
module.exports = {
  name: 'open',
  command: ['open'],
  category: 'group',
  description: 'open command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *open* command executed.');
  }
};
