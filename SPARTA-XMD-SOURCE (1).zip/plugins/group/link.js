
module.exports = {
  name: 'link',
  command: ['link'],
  category: 'group',
  description: 'link command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *link* command executed.');
  }
};
