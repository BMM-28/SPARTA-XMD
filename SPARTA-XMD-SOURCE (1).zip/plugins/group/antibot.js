
module.exports = {
  name: 'antibot',
  command: ['antibot'],
  category: 'group',
  description: 'antibot command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *antibot* command executed.');
  }
};
