
module.exports = {
  name: 'tagadmin',
  command: ['tagadmin'],
  category: 'group',
  description: 'tagadmin command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *tagadmin* command executed.');
  }
};
