
module.exports = {
  name: 'resetlink',
  command: ['resetlink'],
  category: 'group',
  description: 'resetlink command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *resetlink* command executed.');
  }
};
