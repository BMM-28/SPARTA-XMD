
module.exports = {
  name: 'total',
  command: ['total'],
  category: 'group',
  description: 'total command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *total* command executed.');
  }
};
