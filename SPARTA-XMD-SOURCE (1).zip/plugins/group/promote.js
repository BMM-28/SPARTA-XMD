
module.exports = {
  name: 'promote',
  command: ['promote'],
  category: 'group',
  description: 'promote command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *promote* command executed.');
  }
};
