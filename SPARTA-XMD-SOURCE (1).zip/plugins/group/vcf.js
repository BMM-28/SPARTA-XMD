
module.exports = {
  name: 'vcf',
  command: ['vcf'],
  category: 'group',
  description: 'vcf command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *vcf* command executed.');
  }
};
