
module.exports = {
  name: 'tagall',
  command: ['tagall'],
  category: 'group',
  description: 'tagall command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *tagall* command executed.');
  }
};
