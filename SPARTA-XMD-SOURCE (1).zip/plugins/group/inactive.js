
module.exports = {
  name: 'inactive',
  command: ['inactive'],
  category: 'group',
  description: 'inactive command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *inactive* command executed.');
  }
};
