
module.exports = {
  name: 'demote',
  command: ['demote'],
  category: 'group',
  description: 'demote command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *demote* command executed.');
  }
};
