
module.exports = {
  name: 'hidetag',
  command: ['hidetag'],
  category: 'group',
  description: 'hidetag command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *hidetag* command executed.');
  }
};
