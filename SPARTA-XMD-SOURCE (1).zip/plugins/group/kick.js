
module.exports = {
  name: 'kick',
  command: ['kick'],
  category: 'group',
  description: 'kick command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *kick* command executed.');
  }
};
