
module.exports = {
  name: 'antilink',
  command: ['antilink'],
  category: 'group',
  description: 'antilink command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *antilink* command executed.');
  }
};
