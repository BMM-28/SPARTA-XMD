
module.exports = {
  name: 'antigroupmention',
  command: ['antigroupmention'],
  category: 'group',
  description: 'antigroupmention command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *antigroupmention* command executed.');
  }
};
