
module.exports = {
  name: 'cancelkick',
  command: ['cancelkick'],
  category: 'group',
  description: 'cancelkick command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *cancelkick* command executed.');
  }
};
