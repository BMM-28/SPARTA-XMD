
module.exports = {
  name: 'close',
  command: ['close'],
  category: 'group',
  description: 'close command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *close* command executed.');
  }
};
