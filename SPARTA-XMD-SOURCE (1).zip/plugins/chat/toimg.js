
module.exports = {
  name: 'toimg',
  command: ['toimg'],
  category: 'chat',
  description: 'toimg command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *toimg* command executed.');
  }
};
