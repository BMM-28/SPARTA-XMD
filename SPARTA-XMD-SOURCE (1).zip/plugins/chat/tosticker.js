
module.exports = {
  name: 'tosticker',
  command: ['tosticker'],
  category: 'chat',
  description: 'tosticker command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *tosticker* command executed.');
  }
};
