
module.exports = {
  name: 'remini',
  command: ['remini'],
  category: 'chat',
  description: 'remini command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *remini* command executed.');
  }
};
