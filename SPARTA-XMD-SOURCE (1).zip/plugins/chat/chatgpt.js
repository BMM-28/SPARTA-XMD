
module.exports = {
  name: 'chatgpt',
  command: ['chatgpt'],
  category: 'chat',
  description: 'chatgpt command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *chatgpt* command executed.');
  }
};
