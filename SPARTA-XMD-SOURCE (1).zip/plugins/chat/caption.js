
module.exports = {
  name: 'caption',
  command: ['caption'],
  category: 'chat',
  description: 'caption command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *caption* command executed.');
  }
};
