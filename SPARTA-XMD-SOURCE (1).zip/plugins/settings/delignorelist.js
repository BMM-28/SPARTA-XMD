
module.exports = {
  name: 'delignorelist',
  command: ['delignorelist'],
  category: 'settings',
  description: 'delignorelist command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *delignorelist* command executed.');
  }
};
