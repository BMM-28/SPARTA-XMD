
module.exports = {
  name: 'setownername',
  command: ['setownername'],
  category: 'settings',
  description: 'setownername command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setownername* command executed.');
  }
};
