
module.exports = {
  name: 'autobio',
  command: ['autobio'],
  category: 'settings',
  description: 'autobio command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *autobio* command executed.');
  }
};
