
module.exports = {
  name: 'listwarn',
  command: ['listwarn'],
  category: 'settings',
  description: 'listwarn command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *listwarn* command executed.');
  }
};
