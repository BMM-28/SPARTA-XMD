
module.exports = {
  name: 'setstickerpackname',
  command: ['setstickerpackname'],
  category: 'settings',
  description: 'setstickerpackname command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setstickerpackname* command executed.');
  }
};
