
module.exports = {
  name: 'addignorelist',
  command: ['addignorelist'],
  category: 'settings',
  description: 'addignorelist command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *addignorelist* command executed.');
  }
};
