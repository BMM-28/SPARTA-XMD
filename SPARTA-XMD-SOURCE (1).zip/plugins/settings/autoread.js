
module.exports = {
  name: 'autoread',
  command: ['autoread'],
  category: 'settings',
  description: 'autoread command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *autoread* command executed.');
  }
};
