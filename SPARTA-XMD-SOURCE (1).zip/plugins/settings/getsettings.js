
module.exports = {
  name: 'getsettings',
  command: ['getsettings'],
  category: 'settings',
  description: 'getsettings command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *getsettings* command executed.');
  }
};
