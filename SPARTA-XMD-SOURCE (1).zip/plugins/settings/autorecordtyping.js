
module.exports = {
  name: 'autorecordtyping',
  command: ['autorecordtyping'],
  category: 'settings',
  description: 'autorecordtyping command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *autorecordtyping* command executed.');
  }
};
