
module.exports = {
  name: 'alwaysonline',
  command: ['alwaysonline'],
  category: 'settings',
  description: 'alwaysonline command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *alwaysonline* command executed.');
  }
};
