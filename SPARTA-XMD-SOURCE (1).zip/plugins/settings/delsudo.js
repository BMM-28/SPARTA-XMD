
module.exports = {
  name: 'delsudo',
  command: ['delsudo'],
  category: 'settings',
  description: 'delsudo command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *delsudo* command executed.');
  }
};
