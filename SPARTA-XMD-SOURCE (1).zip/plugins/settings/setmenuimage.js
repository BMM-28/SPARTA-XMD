
module.exports = {
  name: 'setmenuimage',
  command: ['setmenuimage'],
  category: 'settings',
  description: 'setmenuimage command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setmenuimage* command executed.');
  }
};
