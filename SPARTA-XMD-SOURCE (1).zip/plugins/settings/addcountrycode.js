
module.exports = {
  name: 'addcountrycode',
  command: ['addcountrycode'],
  category: 'settings',
  description: 'addcountrycode command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *addcountrycode* command executed.');
  }
};
