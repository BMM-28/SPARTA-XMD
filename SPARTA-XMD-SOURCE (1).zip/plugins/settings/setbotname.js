
module.exports = {
  name: 'setbotname',
  command: ['setbotname'],
  category: 'settings',
  description: 'setbotname command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setbotname* command executed.');
  }
};
