
module.exports = {
  name: 'anticall',
  command: ['anticall'],
  category: 'settings',
  description: 'anticall command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *anticall* command executed.');
  }
};
