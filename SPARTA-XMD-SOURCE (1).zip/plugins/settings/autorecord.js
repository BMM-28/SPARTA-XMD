
module.exports = {
  name: 'autorecord',
  command: ['autorecord'],
  category: 'settings',
  description: 'autorecord command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *autorecord* command executed.');
  }
};
