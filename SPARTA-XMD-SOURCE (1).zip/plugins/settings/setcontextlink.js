
module.exports = {
  name: 'setcontextlink',
  command: ['setcontextlink'],
  category: 'settings',
  description: 'setcontextlink command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setcontextlink* command executed.');
  }
};
