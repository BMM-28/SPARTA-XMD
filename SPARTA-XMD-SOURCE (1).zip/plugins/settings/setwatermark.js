
module.exports = {
  name: 'setwatermark',
  command: ['setwatermark'],
  category: 'settings',
  description: 'setwatermark command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setwatermark* command executed.');
  }
};
