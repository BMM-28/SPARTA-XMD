
module.exports = {
  name: 'setwarn',
  command: ['setwarn'],
  category: 'settings',
  description: 'setwarn command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setwarn* command executed.');
  }
};
