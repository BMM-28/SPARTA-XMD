
module.exports = {
  name: 'delcountrycode',
  command: ['delcountrycode'],
  category: 'settings',
  description: 'delcountrycode command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *delcountrycode* command executed.');
  }
};
