
module.exports = {
  name: 'autoblock',
  command: ['autoblock'],
  category: 'settings',
  description: 'autoblock command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *autoblock* command executed.');
  }
};
