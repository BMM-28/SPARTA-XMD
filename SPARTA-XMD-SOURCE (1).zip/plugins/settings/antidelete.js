
module.exports = {
  name: 'antidelete',
  command: ['antidelete'],
  category: 'settings',
  description: 'antidelete command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *antidelete* command executed.');
  }
};
