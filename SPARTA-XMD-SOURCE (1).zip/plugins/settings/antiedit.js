
module.exports = {
  name: 'antiedit',
  command: ['antiedit'],
  category: 'settings',
  description: 'antiedit command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *antiedit* command executed.');
  }
};
