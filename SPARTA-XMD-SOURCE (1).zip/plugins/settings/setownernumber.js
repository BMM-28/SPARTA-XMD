
module.exports = {
  name: 'setownernumber',
  command: ['setownernumber'],
  category: 'settings',
  description: 'setownernumber command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setownernumber* command executed.');
  }
};
