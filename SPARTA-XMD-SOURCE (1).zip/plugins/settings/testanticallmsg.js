
module.exports = {
  name: 'testanticallmsg',
  command: ['testanticallmsg'],
  category: 'settings',
  description: 'testanticallmsg command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *testanticallmsg* command executed.');
  }
};
