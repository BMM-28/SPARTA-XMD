
module.exports = {
  name: 'listcountrycode',
  command: ['listcountrycode'],
  category: 'settings',
  description: 'listcountrycode command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *listcountrycode* command executed.');
  }
};
