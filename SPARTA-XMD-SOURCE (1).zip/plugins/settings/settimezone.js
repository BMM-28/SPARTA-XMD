
module.exports = {
  name: 'settimezone',
  command: ['settimezone'],
  category: 'settings',
  description: 'settimezone command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *settimezone* command executed.');
  }
};
