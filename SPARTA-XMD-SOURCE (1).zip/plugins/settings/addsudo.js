
module.exports = {
  name: 'addsudo',
  command: ['addsudo'],
  category: 'settings',
  description: 'addsudo command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *addsudo* command executed.');
  }
};
