
module.exports = {
  name: 'setanticallmsg',
  command: ['setanticallmsg'],
  category: 'settings',
  description: 'setanticallmsg command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setanticallmsg* command executed.');
  }
};
