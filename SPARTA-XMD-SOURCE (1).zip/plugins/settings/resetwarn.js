
module.exports = {
  name: 'resetwarn',
  command: ['resetwarn'],
  category: 'settings',
  description: 'resetwarn command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *resetwarn* command executed.');
  }
};
