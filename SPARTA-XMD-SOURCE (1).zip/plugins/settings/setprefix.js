
module.exports = {
  name: 'setprefix',
  command: ['setprefix'],
  category: 'settings',
  description: 'setprefix command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setprefix* command executed.');
  }
};
