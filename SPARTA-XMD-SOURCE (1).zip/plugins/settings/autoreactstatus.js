
module.exports = {
  name: 'autoreactstatus',
  command: ['autoreactstatus'],
  category: 'settings',
  description: 'autoreactstatus command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *autoreactstatus* command executed.');
  }
};
