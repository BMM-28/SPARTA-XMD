
module.exports = {
  name: 'setstickerauthor',
  command: ['setstickerauthor'],
  category: 'settings',
  description: 'setstickerauthor command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setstickerauthor* command executed.');
  }
};
