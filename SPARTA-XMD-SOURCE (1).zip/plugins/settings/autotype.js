
module.exports = {
  name: 'autotype',
  command: ['autotype'],
  category: 'settings',
  description: 'autotype command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *autotype* command executed.');
  }
};
