
module.exports = {
  name: 'delanticallmsg',
  command: ['delanticallmsg'],
  category: 'settings',
  description: 'delanticallmsg command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *delanticallmsg* command executed.');
  }
};
