
module.exports = {
  name: 'autoreact',
  command: ['autoreact'],
  category: 'settings',
  description: 'autoreact command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *autoreact* command executed.');
  }
};
