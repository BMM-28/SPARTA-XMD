
module.exports = {
  name: 'chatbot',
  command: ['chatbot'],
  category: 'settings',
  description: 'chatbot command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *chatbot* command executed.');
  }
};
