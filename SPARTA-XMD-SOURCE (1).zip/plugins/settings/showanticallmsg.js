
module.exports = {
  name: 'showanticallmsg',
  command: ['showanticallmsg'],
  category: 'settings',
  description: 'showanticallmsg command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *showanticallmsg* command executed.');
  }
};
