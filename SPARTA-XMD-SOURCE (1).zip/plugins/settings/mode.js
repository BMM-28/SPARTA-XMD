
module.exports = {
  name: 'mode',
  command: ['mode'],
  category: 'settings',
  description: 'mode command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *mode* command executed.');
  }
};
