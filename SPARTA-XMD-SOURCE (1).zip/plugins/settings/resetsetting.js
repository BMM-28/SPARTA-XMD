
module.exports = {
  name: 'resetsetting',
  command: ['resetsetting'],
  category: 'settings',
  description: 'resetsetting command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *resetsetting* command executed.');
  }
};
