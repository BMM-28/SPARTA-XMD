
module.exports = {
  name: 'antibug',
  command: ['antibug'],
  category: 'settings',
  description: 'antibug command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *antibug* command executed.');
  }
};
