
module.exports = {
  name: 'antideletestatus',
  command: ['antideletestatus'],
  category: 'settings',
  description: 'antideletestatus command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *antideletestatus* command executed.');
  }
};
