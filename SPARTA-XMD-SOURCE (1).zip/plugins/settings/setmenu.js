
module.exports = {
  name: 'setmenu',
  command: ['setmenu'],
  category: 'settings',
  description: 'setmenu command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *setmenu* command executed.');
  }
};
