const handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, {
    text: `📌 *ABOUT SPARTA-XMD BOT*

🤖 *Bot Name:* SPARTA-XMD
🧠 *Developer:* SPARTA-28
💙 *Support Dev:* KEI
⚔️ *Clan:* BUGSTRIKE UNIT
🤝 *Contributors:* XFACTA, RUNA, BADGYAL
🤖 *Powered by:* GPT AI
📞 *Support Contact:* wa.me/254795452444
🔗 *Support Channel:* https://whatsapp.com/channel/0029VbBCtfc6GcGHobujxG2R
👥 *Support Group:* https://chat.whatsapp.com/K4irACE8wMw7KTtFJTSrfg?mode=ac_t
🌍 *Status:* Stable 🔵`
  }, { quoted: m });
};
handler.command = ['about'];
handler.tags = ['info'];
handler.help = ['about'];
export default handler;