const handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, {
    text: `╭───〔 👑 SPARTA-XMD CREDITS 〕───╮
│ 🧠 Developer: SPARTA-28
│ 💙 Mrs Dev: KEI
│ 🤝 Friend: XFACTA
│ 💪 Friend: RUNA
│ 🤝 Friend: BADGYAL
│ 🤖 Helper: GPT
│ ⚔️ Clan: BUGSTRIKE UNIT
╰──────────────────────────────╯`
  }, { quoted: m });
};
handler.command = ['credits'];
handler.tags = ['info'];
handler.help = ['credits'];
export default handler;