
module.exports = {
  name: 'unmute',
  command: ['unmute'],
  category: 'moderation',
  description: 'unmute command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *unmute* command executed.');
  }
};
