
module.exports = {
  name: 'purge',
  command: ['purge'],
  category: 'moderation',
  description: 'purge command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *purge* command executed.');
  }
};
