
module.exports = {
  name: 'mute',
  command: ['mute'],
  category: 'moderation',
  description: 'mute command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *mute* command executed.');
  }
};
