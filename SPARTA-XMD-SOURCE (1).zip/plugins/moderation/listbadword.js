
module.exports = {
  name: 'listbadword',
  command: ['listbadword'],
  category: 'moderation',
  description: 'listbadword command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *listbadword* command executed.');
  }
};
