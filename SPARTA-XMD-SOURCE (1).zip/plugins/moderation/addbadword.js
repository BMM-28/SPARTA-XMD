
module.exports = {
  name: 'addbadword',
  command: ['addbadword'],
  category: 'moderation',
  description: 'addbadword command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *addbadword* command executed.');
  }
};
