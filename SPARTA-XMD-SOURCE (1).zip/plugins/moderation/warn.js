
module.exports = {
  name: 'warn',
  command: ['warn'],
  category: 'moderation',
  description: 'warn command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *warn* command executed.');
  }
};
