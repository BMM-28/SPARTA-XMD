
module.exports = {
  name: 'resetwarn',
  command: ['resetwarn'],
  category: 'moderation',
  description: 'resetwarn command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *resetwarn* command executed.');
  }
};
