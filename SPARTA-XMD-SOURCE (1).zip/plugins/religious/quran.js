
module.exports = {
  name: 'quran',
  command: ['quran'],
  category: 'religious',
  description: 'quran command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *quran* command executed.');
  }
};
