
module.exports = {
  name: 'bible',
  command: ['bible'],
  category: 'religious',
  description: 'bible command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *bible* command executed.');
  }
};
