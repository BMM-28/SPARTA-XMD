
module.exports = {
  name: 'weather',
  command: ['weather'],
  category: 'search',
  description: 'weather command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *weather* command executed.');
  }
};
