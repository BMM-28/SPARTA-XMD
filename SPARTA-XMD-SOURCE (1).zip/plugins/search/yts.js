
module.exports = {
  name: 'yts',
  command: ['yts'],
  category: 'search',
  description: 'yts command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *yts* command executed.');
  }
};
