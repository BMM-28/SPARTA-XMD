
module.exports = {
  name: 'shazam',
  command: ['shazam'],
  category: 'search',
  description: 'shazam command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *shazam* command executed.');
  }
};
