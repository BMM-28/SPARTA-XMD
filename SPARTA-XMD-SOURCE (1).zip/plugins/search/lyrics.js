
module.exports = {
  name: 'lyrics',
  command: ['lyrics'],
  category: 'search',
  description: 'lyrics command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *lyrics* command executed.');
  }
};
