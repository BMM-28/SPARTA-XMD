
module.exports = {
  name: 'donate',
  command: ['donate'],
  category: 'support',
  description: 'donate command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *donate* command executed.');
  }
};
