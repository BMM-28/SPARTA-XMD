
module.exports = {
  name: 'contact',
  command: ['contact'],
  category: 'support',
  description: 'contact command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *contact* command executed.');
  }
};
