
module.exports = {
  name: 'support',
  command: ['support'],
  category: 'support',
  description: 'support command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *support* command executed.');
  }
};
