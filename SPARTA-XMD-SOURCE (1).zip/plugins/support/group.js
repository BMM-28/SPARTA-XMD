
module.exports = {
  name: 'group',
  command: ['group'],
  category: 'support',
  description: 'group command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *group* command executed.');
  }
};
