
module.exports = {
  name: 'google',
  command: ['google'],
  category: 'custom',
  description: 'google command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *google* command executed.');
  }
};
