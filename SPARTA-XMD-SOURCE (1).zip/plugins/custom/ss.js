
module.exports = {
  name: 'ss',
  command: ['ss'],
  category: 'custom',
  description: 'ss command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *ss* command executed.');
  }
};
