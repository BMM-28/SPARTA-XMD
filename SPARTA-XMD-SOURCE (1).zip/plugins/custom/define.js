
module.exports = {
  name: 'define',
  command: ['define'],
  category: 'custom',
  description: 'define command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *define* command executed.');
  }
};
