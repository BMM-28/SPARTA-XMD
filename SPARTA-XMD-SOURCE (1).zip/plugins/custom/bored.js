
module.exports = {
  name: 'bored',
  command: ['bored'],
  category: 'custom',
  description: 'bored command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *bored* command executed.');
  }
};
