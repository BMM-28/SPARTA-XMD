
module.exports = {
  name: 'time',
  command: ['time'],
  category: 'custom',
  description: 'time command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *time* command executed.');
  }
};
