
module.exports = {
  name: 'quote',
  command: ['quote'],
  category: 'custom',
  description: 'quote command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *quote* command executed.');
  }
};
