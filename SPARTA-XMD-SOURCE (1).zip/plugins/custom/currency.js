
module.exports = {
  name: 'currency',
  command: ['currency'],
  category: 'custom',
  description: 'currency command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *currency* command executed.');
  }
};
