
module.exports = {
  name: 'short',
  command: ['short'],
  category: 'custom',
  description: 'short command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *short* command executed.');
  }
};
