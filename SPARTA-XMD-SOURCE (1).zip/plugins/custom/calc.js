
module.exports = {
  name: 'calc',
  command: ['calc'],
  category: 'custom',
  description: 'calc command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *calc* command executed.');
  }
};
