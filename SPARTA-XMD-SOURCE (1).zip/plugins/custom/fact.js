
module.exports = {
  name: 'fact',
  command: ['fact'],
  category: 'custom',
  description: 'fact command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *fact* command executed.');
  }
};
