
module.exports = {
  name: 'gpt',
  command: ['gpt'],
  category: 'ai',
  description: 'gpt command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *gpt* command executed.');
  }
};
