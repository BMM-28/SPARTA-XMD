
module.exports = {
  name: 'describe',
  command: ['describe'],
  category: 'ai',
  description: 'describe command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *describe* command executed.');
  }
};
