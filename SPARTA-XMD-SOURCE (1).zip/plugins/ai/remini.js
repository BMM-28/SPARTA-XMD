
module.exports = {
  name: 'remini',
  command: ['remini'],
  category: 'ai',
  description: 'remini command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *remini* command executed.');
  }
};
