
module.exports = {
  name: 'disabledefense',
  command: ['disabledefense'],
  category: 'defense',
  description: 'disabledefense command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *disabledefense* command executed.');
  }
};
