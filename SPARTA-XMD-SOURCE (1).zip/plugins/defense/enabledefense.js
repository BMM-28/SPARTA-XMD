
module.exports = {
  name: 'enabledefense',
  command: ['enabledefense'],
  category: 'defense',
  description: 'enabledefense command',
  async handler(m, { conn, args, text }) {
    m.reply('✅ *enabledefense* command executed.');
  }
};
