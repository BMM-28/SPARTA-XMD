# SPARTA-XMD Session Generator
This directory contains session generation scripts.