
const express = require('express');
const { default: makeWASocket, useSingleFileAuthState, fetchLatestBaileysVersion, makeInMemoryStore } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const { join } = require('path');
const fs = require('fs');

const app = express();
const port = process.env.PORT || 3000;

const sessionFolder = './sessions';
if (!fs.existsSync(sessionFolder)) fs.mkdirSync(sessionFolder);

const { state, saveState } = useSingleFileAuthState(join(sessionFolder, 'auth_info.json'));

async function connectToWhatsApp() {
  const { version, isLatest } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: true,
    browser: ['SPARTA-XMD-SessionGen', 'Safari', '1.0'],
  });

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) console.log('📲 Scan the QR code above to login');
    if (connection === 'close') {
      const shouldReconnect = lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log('connection closed due to', lastDisconnect.error, ', reconnecting:', shouldReconnect);
      if (shouldReconnect) connectToWhatsApp();
    } else if (connection === 'open') {
      console.log('✅ Logged in');
    }
  });

  sock.ev.on('creds.update', saveState);
}

app.get('/', (req, res) => {
  res.send('<h2>SPARTA-XMD Session Generator</h2><pre>Scan the QR from terminal</pre>');
});

app.listen(port, () => {
  console.log(`🌐 Session Generator running at http://localhost:${port}`);
  connectToWhatsApp();
});
